let home = "http://localhost:8080"


async function login() {
    let login = {
        name: $('#loginName').val(),
        password: $('#loginPassword').val()
    };
    let response = await $.ajax({
        type: 'post',
        url: '/api/user/login',
        contentType: 'application/json',
        data: JSON.stringify(login),
        success: (data) => {
            alert('로그인 성공');
            location.href=home+"/index.html";
        },
        error: (error) => {
            alert('로그인에 실패하였습니다.');
            console.log(JSON.stringify(error));
        },
    });
}

async function func1() {
    alert("문답지 이상유무 보고");
    let user = 1;

    let response = await $.ajax({
            type: 'post',
            url: '/api/user/login',
            contentType: 'application/json',
            data: JSON.stringify(user),
            success: (data) => {
                alert("유저 정보 획득득")
               location.href=home+"/index.html";
            },
            error: (error) => {
                alert('로그인에 실패하였습니다.');
                console.log(JSON.stringify(error));
            },
        });
}

async function func2() {
    alert("시험장 응시자 현황보고");

}